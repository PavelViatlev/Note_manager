# Тесты (функции) для основных функций менеджера заметок

import unittest
from data.load_notes_json import load_notes_json
from data.save_notes_json import save_notes_json#, load_notes_json
from interface import display_notes_function, search_notes_function

notes_test = [{'Имя': 'Антон', 'Заголовок': 'Диссертация', 'Описание': 'Глава 1'},
              {'Имя': 'Павел', 'Заголовок': 'Горные лыжи', 'Описание': 'Аппатиты'},
              {'Имя': 'Павел', 'Заголовок': 'Обучение', 'Описание': 'Этап 5'}]

class TestNoteManager(unittest.TestCase): # Класс тестов функций менеджера заметок

    def test_save_and_load_note_json(self): # Тест функций сохранений и загрузки заметок
        save_notes_json(notes_test, 'test.json')
        loaded_notes = load_notes_json('test.json')
#        print(loaded_notes)
        self.assertEqual(notes_test, loaded_notes)

    def test_display_search_note(self):
        result_display = display_notes_function.display_notes(notes_test)
        result_search = search_notes_function.search_notes(notes_test, "лыжи")
        self.assertEqual(result_search, 1)
        self.assertEqual(result_display, 3)
    
    def test_validation_note(self):
        note_valid = {'Имя': 'Антон', 'Заголовок': 'Диссертация', 'Описание': 'Глава 1',
                      'Статус': 'выполнена', 'Дата создания': '20.11.2024', 'Дедлайн': '26.11.2024'}
        note_nonvalid = {'имя': 'Антон', 'заголовок': 'Диссертация', 'описание': 'Глава 1',
                         'статус': 'выполнена', 'дата создания': '20.11.2024', 'дедлайн': '26.11.2024'}
        note_test = note_valid.keys()
        note_test_val = note_valid.values()
        for i in note_test:
            self.assertIn(i, note_test) # проверка правильных ключей заметки
            self.assertNotIn(i, note_nonvalid) # проверка неправильных ключей заметки
        self.assertTrue('Антон' in note_test_val) # проверка значения заметки

def main():
    pass

if __name__ == '__main__':
    pass
#    unittest.main() # загрузка и запуск тестов из файла/модуля
