from tests import check_deadline, TestNoteManager

def main():
    pass

if __name__ == '__main__':
    main()