# Input Data from user
Username = input('Введите имя пользователя: ') # Имя пользователя
print('Username:', Username)
Title = input('Введите заголовок заметки: ') # Заголовок заметки
print('Title:', Title)
Content = input('Введите описание заметки: ') # Описание заметки
print('Content:', Content)
Status = input('Введите статус заметки: ') # Статус заметки
print('Status:', Status)
Created_date = input('Введите дату создания заметки в формате-"день.месяц.год": ')
print('Created date:', Created_date)
Issue_date = input('Введите дату истечения заметки (дедлайн)в формате-"день.месяц.год": ')
print('Issue date:', Issue_date)