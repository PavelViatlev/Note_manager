from data import save_notes_json, load_notes_json

def main():
    pass

if __name__ == '__main__':
    main()