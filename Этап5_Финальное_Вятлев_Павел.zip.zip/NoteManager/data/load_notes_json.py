# Функция читает заметки из файла json и возвращает их в виде списка словарей. Для Grade 1. Этап 5: Зад. 4
import json

def load_notes_json(filename):
    with open(filename, 'r', encoding='utf-8') as file: # блок для автоматического закрытия файла
        data_json = json.load(file)
    return data_json

#def main():
#    load_notes_json('json_file.json')

if __name__ == '__main__':
    load_notes_json('json_file.json')
    #main()